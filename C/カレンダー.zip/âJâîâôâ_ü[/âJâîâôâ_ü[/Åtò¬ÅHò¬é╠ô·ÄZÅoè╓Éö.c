#include<�J�����_�[.h>


#if 1


void	haki(char holidays[N_MONTH][MAX_HOLI_TBL],int year){

int springEQ; // ���߂�t���̓�
int fallEQ; // ���߂�H���̓�

if (year <= 1899) {
	springEQ = (int)(19.8277 + 0.242194 * (year - 1980) - ((year - 1983) / 4));
	fallEQ = (int)(22.2588 + 0.242194 * (year - 1980) - ((year - 1983) / 4));
}

else if (year >= 1900 && year <= 1979) {
	springEQ = (int)(20.8357 + 0.242194 * (year - 1980) - ((year - 1983) / 4));
	fallEQ = (int)(23.2588 + 0.242194 * (year - 1980) - ((year - 1983) / 4));
}

else if (year >= 1980 && year <= 2099) {
	springEQ = (int)(20.8431 + 0.242194 * (year - 1980) - ((year - 1980) / 4));
	fallEQ = (int)(23.2488 + 0.242194 * (year - 1980) - ((year - 1980) / 4));
}

else if (year >= 2100) {
	springEQ = (int)(21.851 + 0.242194 * (year - 1980) - ((year - 1980) / 4));
	fallEQ = (int)(24.2488 + 0.242194 * (year - 1980) - ((year - 1980) / 4));
}

holidays[MAR][SPRING_EQ] = springEQ; // �t���̓�������
holidays[SEP][FALL_EQ] = fallEQ; // �H���̓�������

}
#endif 