#include<�J�����_�[.h>

int leapyear(int	year) {
	int	judge=0;				//judge����
	if (year % 400 == 0	)
	{
		judge = 1;

	}
	if (year % 100 ==0)
	{
		judge = 0;


	}
	if (year % 4 ==0)
	{
		judge = 1;


	}

	return	judge;

}